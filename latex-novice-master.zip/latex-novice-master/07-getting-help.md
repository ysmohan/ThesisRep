---
layout: page
title: LaTeX
subtitle: Where to from here?
minutes: 
---

# TODO: mention popular and useful packages such as Beamer, tikz/pgf, lots more.
# TODO: mention common resources such as lshort, TeXbook, Mittelbach & Goosens, package documentation.
